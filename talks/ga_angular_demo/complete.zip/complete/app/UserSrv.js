module.service('UserSrv', function () {
	var users = new Firebase('https://bananas-and-cherries.firebaseio.com/users');

	this.createUser = function (data, callback) {
		users.push().set(data, function (result) {
			callback(result);
		});
	};

	this.getUsers = function (callback) {
		users.once('value', function (result) {
			return callback(result.val());
		});
	};
});