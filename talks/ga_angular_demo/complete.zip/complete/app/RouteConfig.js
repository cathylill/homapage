module.config(['$routeProvider', function ($routeProvider, $locationProvider) {
    $routeProvider
        .when("/signup", {
            templateUrl: 'signup.html',
            controller: 'SignupCtrl' })
        .when("/lists", {
            templateUrl: 'list.html',
            controller: 'ListsCtrl' })
        .when("/lists/:list", {
            templateUrl: 'items.html',
            controller: 'ItemsCtrl' })
        .otherwise({ redirectTo: "/lists" });
}]);