function ItemsCtrl ($scope) {
    $scope.items = [];
    $scope.addItem = function () {};
};