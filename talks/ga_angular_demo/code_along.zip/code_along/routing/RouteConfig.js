module.config(function () {
    $routeProvider
        .when("/signup", {
            templateUrl: 'signup.html',
            controller: 'SignupCtrl' })
        .otherwise({ redirectTo: "/items" });
}]);