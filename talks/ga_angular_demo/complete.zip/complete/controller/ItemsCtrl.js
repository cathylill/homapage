function ItemsCtrl ($scope) {
    $scope.items = [];
    $scope.addItem = function () {
        $scope.items.push($scope.itemText);
        $scope.itemText = '';
    };
};