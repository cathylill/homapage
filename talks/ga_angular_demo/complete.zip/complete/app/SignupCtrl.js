module.controller('SignupCtrl', ['$scope', 'UserSrv', function ($scope, UserSrv) {
    $scope.signup = function () {
    	UserSrv.createUser({
    		name: $scope.userName,
    		phone: $scope.userPhone,
    		email: $scope.userEmail
    	}, function () {
	        $scope.userName = '';
	        $scope.userPhone = '';
	        $scope.userEmail = '';
	        $scope.signupForm.$setPristine();
	        updateUsers();
    	});
    };

    function updateUsers() {
		UserSrv.getUsers(function (users) {
			$scope.$apply(function () {
				$scope.users = users;
			});
		});
	};

	updateUsers();
}]);